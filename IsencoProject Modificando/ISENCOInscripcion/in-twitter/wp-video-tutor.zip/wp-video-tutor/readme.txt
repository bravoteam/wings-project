=== WP Video Tutor ===
Contributors: iqace
Tags: video, tutor, tutorials, admin panel, help, videos, tutorial
Requires at least: 2.9
Tested up to: 2.9
Stable tag: trunk

WP Video Tutor puts video tutorials in the help section of the WordPress Admin Panel.

== Description ==

WP Video Tutor puts video tutorials in the help section of the WordPress Admin Panel. This enables Administrators to see a video tutorial about the page they are on in their Admin Panel by clicking on the help tab.

== Installation ==

1. Upload `wpvideotutor.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Click on the help tab at the top of a page in the admin panel to watch a video about that page.

== Frequently Asked Questions ==

= Does this work with WordPress MU =

IQ Ace, LLC has not tested this plugin with WordPress MU yet.

== Screenshots ==

1. This screen shot shows a video tutorial at the top of a page in the admin panel.