=== WORDPRESS VIDEO GALLERY ===
Contributors: Contus Support
Tags: Video Player plugin, video, flash player, flv player, WORDPRESS VIDEO GALLERY, flv player wordpress, hd flv player, youtube plugin, youtube Video Player, high definition Video Player, flash, play flv wordpress, player, Video Plugin, wp flv player, wp flv plugin, flv player 2009,  WORDPRESS VIDEO GALLERY, wp flv, wordpress flv plugin, wp hd flv player, flv player plugin, wordpress flv player
Requires at least: 2.8
Tested up to: 3.0.5
Stable tag: 1.3
Get the most exciting FLV player in the internet, designed and modified to suit your Wordpress websites.  Installing this Video Plugin is real easy and if you have any difficulty in installation, contact our Video Player support team and quickly resolve your issue.  You can either download this Video Plugin directly from our website or through Wordpress plugins page itself.  This WORDPRESS VIDEO GALLERY Version  has many advanced features that you cannot find elsewhere, such as that you can play youtube videos directly through this player, and it can also aptly be called as a youtube player.

== Description ==

Video Gallery Demo - http://www.apptha.com/demo/wordpress/contushome/

Video Gallery Home Page - http://www.apptha.com/category/extension/Wordpress/Video-Gallery

Contus Best Wordpress Video Gallery Plugin has a whole set of all utile features such as Options to have quickly visible options such as recent Videos, popular Videos and featured Videos and the ability to control number and order of these from back end, FLV & H.264 encoded video including MP4, M4V, M4A, MOV, Mp4v, F4V, social networking comments from the gallery page (like for Facebook), provision to alter width, height, skin, theme, aspect ratio, volume, downloads etc. from the backend, social Media Bookmark option (diggit, myspace, facebook, del.icio.us, spurl, furl, google), multiple Playlists, views count for video, Supported in the latest Wordpress 3.0.3 and all the other regular and utile features we could see in popular video sharing sites.

* HTML 5
* Easy to install WORDPRESS VIDEO GALLERY Plugin comes with complete control on player through admin panel, with fantastic support.
* FLV Video plugin which can play FLV video & H.264 encoded video including MP3, MP4, M4V, M4A, MOV, Mp4v, F4V formats.
* Video Player which has option send to friend feature.
* Can have Recent Videos,Popular Videos and Featured Videos.
* Recent , Popular , Featured Videos are widgets in our plugin .So can enable or disable at admin.
* Tags
* Flexible player size
* Ability to turn on/off, share, volume functions
* This Video Plugin has Full screen feature
* 1X, 2X and 3X zoom capabilities
* Logo (opacity control)
* Mouse wheel support (Rewind and forward)
* Playlist Option available in this WORDPRESS VIDEO GALLERY Version.
* Individual sort order for each Playlist in this FLV player.
* Add Media Option.
* Directly play youtube videos like a youtube player.
* Multi Language options for Tool tips on Player.
* Show custom ads / videos through Preroll and Postroll options.

== Installation ==

= Minimal Requirements =
* PHP: 5.x.x
* mySQL: 4.0, 4.1 or 5.x
* WordPress: 2.8 or newer

= Recommended Requirements =
* PHP: 5.2.x or newer
* mySQL: 5.x
* WordPress: 2.8 or newer

= Basic Installation =
1. Download and unzip the current version of the WORDPRESS VIDEO GALLERY plugin.
2. Transfer the entire WORDPRESS VIDEO GALLERY directory to your /wp-content/plugins/ directory
3. Activate the WORDPRESS VIDEO GALLERY plugin through the 'Plugins' menu in WordPress
4. That's it! You're done.

== Screenshots ==
Manage Video: http://www.hdflvplayer.net/wordpress-video-gallery/gallery/video-uploadlist.JPG

Upload video file: http://www.hdflvplayer.net/wordpress-video-gallery/gallery/upload-file.JPG 

Upload youtube URL: http://www.hdflvplayer.net/wordpress-video-gallery/gallery/video-upload-file.JPG

Upload custom URL: http://www.hdflvplayer.net/wordpress-video-gallery/gallery/custom-url.JPG

Manage video widgets: http://www.hdflvplayer.net/wordpress-video-gallery/gallery/widgets.JPG

Video gallery(Front-end): http://www.hdflvplayer.net/wordpress-video-gallery/gallery/front-video-page.JPG

Videos(recent,popular,feature): http://www.hdflvplayer.net/wordpress-video-gallery/gallery/recent-popular.JPG

Gallery settings: http://www.hdflvplayer.net/wordpress-video-gallery/gallery/gallery-settings.JPG , http://www.hdflvplayer.net/wordpress-video-gallery/gallery/gallery-settings2.JPG .

== Other Notes ==

= To Add video =
1. Logon to Admin panel.
2. Media -> WORDPRESS VIDEO GALLERY - > Add Video.
3. Provide Youtube URL or Absolute path of the video (Eg.  Upload your videos to videos folder through FTP and provide the path as http://www.yourdomain.com/video/video.mp4).
4. Create and select the playlist from the Right column of the window to assign the video to the particular playlist.
5. Provide the sort / order number next to playlist to play the video in order.

= To change the global settings of the player =
1. Logon to Admin panel.
2. Look for Settings on the Left column and click Contus Gallery Settings Options.
3. Change the settings as you wish.
4. You have options for Home page Recent,Popular,and Featured Videos enable,disable options with limit of rows and columns.

= To Display Side Widgets of the Player Like Recent,Popular,and Featured Videos

1) Logon to Admin Panel.
2) Look for Apperance on the Left column and click Widgets Options.
3) Drag and Drop the options what you want to show in the right side bar.

= To See the Features in the user side
1. There is a Home Page for the videos to display and there Recent,Popular,and Featured Videos will show below the player.
2. Side Widgets also we have the same features with search videos options.

== Frequently Asked Questions ==
= How can i activate video gallery plugin? =
Download the zip file , install it and then rename the plugin name as wordpress-video-gallery.Then activate the plugin.

= Where can I see the working demo of this Video Player or Video Plugin? =
You can see the demo of our WORDPRESS VIDEO GALLERY Version or Video Plugin in this link - http://www.hdflvplayer.net/wordpress-video-gallery/demo/

= What are all the file formats HD FLV PLAYER can play? =
Our FLV player supports FLV & H.264 encoded video including MP3, MP4, M4V, M4A, MOV, Mp4v, F4V formats.

= How to contact the support / development team of our Video Player? =
You can contact us through,
Live Chat at http://www.hdflvplayer.net
Email: support@hdflvplayer.net
Forums at http://www.hdflvplayer.net/forum

= Can I get the WORDPRESS VIDEO GALLERY plugin player customized to my needs? =
Yes, but there will be additional charges based on the request for customization has to be made by the requester.

= What is the advantage of using this Wordpress Video Gallery Plugin? =
To know more features and advantages of our player and this video plugin, visit this link - http://www.hdflvplayer.net/wordpress-video-gallery/contus-video-gallery-features.php

= How to replace or remove the HD FLV Player demo logo from this WORDPRESS VIDEO GALLERY? =
For replacing or removing the demo logo from this FLV player, you need to purchase our commercial version of the player. You can find the Flash FLV player product over here at http://www.hdflvplayer.net/wordpress/
